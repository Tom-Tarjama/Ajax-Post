# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class AjaxPostAppConfig(AppConfig):
    name = 'Ajax_Post_app'
