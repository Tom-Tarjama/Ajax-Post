# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect, HttpResponse

from django.contrib import messages

from models import *

from django.core import serializers

# Create your views here.
def index(request):
	return render(request, "Ajax_Post_app/index.html")

def add_post(request):

	Post.objects.create(post = request.POST['post'])

	posts = Post.objects.order_by("-id")

	return render(request, "Ajax_Post_app/process.html", {'posts': posts})